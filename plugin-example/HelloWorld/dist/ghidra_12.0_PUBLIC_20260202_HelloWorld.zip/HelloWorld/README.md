# Hello World Extension
> Simple Ghidra Extension Base
