def hello():
    return "Hello Ghidra"